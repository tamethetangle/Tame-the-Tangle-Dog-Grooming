# File generated from our OpenAPI spec
# frozen_string_literal: true

module Stripe
  module ApiVersion
    CURRENT = "2025-12-15.clover"
    CURRENT_MAJOR = "clover"
  end
end
