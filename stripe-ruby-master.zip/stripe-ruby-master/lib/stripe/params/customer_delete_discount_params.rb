# File generated from our OpenAPI spec
# frozen_string_literal: true

module Stripe
  class CustomerDeleteDiscountParams < ::Stripe::RequestParams; end
end
