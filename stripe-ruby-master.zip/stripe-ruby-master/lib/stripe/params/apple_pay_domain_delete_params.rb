# File generated from our OpenAPI spec
# frozen_string_literal: true

module Stripe
  class ApplePayDomainDeleteParams < ::Stripe::RequestParams; end
end
