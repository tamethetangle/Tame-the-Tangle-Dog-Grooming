# File generated from our OpenAPI spec
# frozen_string_literal: true

module Stripe
  class CustomerTaxIdDeleteParams < ::Stripe::RequestParams; end
end
