## Running an example

From the examples folder, run:
`RUBYLIB=../lib ruby your_example.rb`

e.g.

`RUBYLIB=../lib ruby event_notification_webhook_handler.rb`

## Adding a new example

1. Clone new_example.rb
2. Implement your example
3. Fill out the file comment. Include a description and key steps that are being demonstrated.
4. Run it (as per above)
5. 👍
